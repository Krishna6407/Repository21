package com.starPattern;

public class C {

//	*
//	* *
//	* * *
//	* * * *
//	* * *
//	* *
//  *

	public static void main(String[] args) {
		int n = 4;
		int k = (n * 2) - 1;
		for (int i = 1; i <= k; i++) {

			if (i <= n) {
				for (int j = 1; j <= i; j++) {
					System.out.print("* ");
				}
			} else {
				for (int j = n-1; j >= (i-n); j--) {
					System.out.print("* ");
				}
			}
			System.out.println();
		}

	}

}
