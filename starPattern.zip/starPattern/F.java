package com.starPattern;

public class F {
	
//	_ _ _ *
//	_ _ * *
//	_ * * *
//	* * * *
//	_ * * *
//	_ _ * *
//	_ _ _ *
	
	
	

}
