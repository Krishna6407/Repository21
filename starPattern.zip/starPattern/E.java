package com.starPattern;

public class E {

//	* * * *
//	_ * * *
//	_ _ * *
//	_ _ _ *

	public static void main(String[] args) {
		for (int i = 1; i <= 4; i++) {
			
			for(int j=2;j<=i;j++) {
				System.out.print("  ");
			}
			
			for(int j=4;j>=i;j--) {
				System.out.print("* ");
			}
			

			System.out.println();
		}

	}

}
